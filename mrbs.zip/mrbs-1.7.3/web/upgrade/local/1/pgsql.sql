INSERT INTO %DB_TBL_PREFIX%variables (variable_name, variable_content)
  VALUES ('local_db_version', '1');
