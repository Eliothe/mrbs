<?php

namespace MRBS\Form;

class ElementDatalist extends Element
{

  public function __construct()
  {
    parent::__construct('datalist');
  }
 
}